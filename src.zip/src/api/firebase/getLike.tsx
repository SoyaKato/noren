import { useEffect, useState } from "react";
import {
  getFirestore,
  collection,
  query,
  where,
  getDocs,
} from "firebase/firestore";
import { firebaseApp } from "@/firebaseConfig/firebaseConfig";
import { CircularProgress } from '@mui/material';

import FavoriteIcon from '@mui/icons-material/Favorite';
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';

interface LikeData {
  evaluate: number;
}

export function GetEvaluateAverage({
  shop_id,
}: {
  shop_id: number;
}): JSX.Element {
  const [evaluateAverage, setEvaluateAverage] = useState<number | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const db = getFirestore(firebaseApp);

  useEffect(() => {
    const getEvaluateData = async () => {
      try {
        const likeCollection = collection(db, "likes");
        const likeQuery = query(likeCollection, where("shop_id", "==", shop_id));
        const snapShotlike = await getDocs(likeQuery);

        const totalEvaluates = snapShotlike.docs.reduce((acc, doc) => {
          const data = doc.data() as LikeData;
          return acc + (data.evaluate === 1 ? 1 : 0);
        }, 0);

        const averageEvaluates =
          snapShotlike.size > 0 ? totalEvaluates / snapShotlike.size : 0;

        setEvaluateAverage(
          Number((averageEvaluates * 5.0).toFixed(2))
        );
      } catch (error) {
        setError("評価データの取得に失敗しました");
        console.error("Error fetching evaluate data:", error);
      } finally {
        setLoading(false);
      }
    };

    getEvaluateData();
  }, [shop_id]);

  if (loading) {
    return <CircularProgress size={20} />;
  }

  if (error) {
    return <div className="error-message">{error}</div>;
  }

  const getFavoriteIcons = (average: number) => {
    if (average >= 4) return 5;
    if (average >= 3) return 4;
    if (average >= 2) return 3;
    if (average >= 1) return 2;
    return 1;
  };

  const filledIconsCount = evaluateAverage !== null ? getFavoriteIcons(evaluateAverage) : 0;
  const emptyIconsCount = 5 - filledIconsCount;

  return (
    <div className="Evaluate">
      {Array.from({ length: filledIconsCount }, (_, index) => (
        <FavoriteIcon key={`filled-${index}`} />
      ))}
      {Array.from({ length: emptyIconsCount }, (_, index) => (
        <FavoriteBorderIcon key={`empty-${index}`} />
      ))}
      {evaluateAverage !== null
        ? `Average Evaluate: ${evaluateAverage}`
        : "評価なし"}
    </div>
  );
}
