import React, { useState, useCallback, memo } from "react";
import { getStorage, ref, uploadBytes } from "firebase/storage";
import { firebaseApp } from "@/firebaseConfig/firebaseConfig";
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import { CircularProgress } from '@mui/material';

const storage = getStorage(firebaseApp);

const styles = {
  container: {
    padding: '40px',
    height: '100%',
  },
  title: {
    marginBottom: '30px',
    color: '#333',
    fontSize: '24px',
    fontWeight: 'bold',
  },
  uploadArea: {
    display: 'flex',
    flexDirection: 'column',
    gap: '20px',
    alignItems: 'center',
  },
  dropZone: {
    width: '100%',
    maxWidth: '500px',
    border: '2px dashed #ccc',
    borderRadius: '8px',
    padding: '40px',
    textAlign: 'center',
    backgroundColor: '#f8f9fa',
    cursor: 'pointer',
    transition: 'border-color 0.3s ease',
  },
  input: {
    display: 'none',
  },
  label: {
    cursor: 'pointer',
  },
  icon: {
    fontSize: '48px',
    color: '#34495e',
    marginBottom: '10px',
  },
  text: {
    color: '#666',
  },
  fileName: {
    marginTop: '10px',
    color: '#34495e',
  },
  previewContainer: {
    width: '100%',
    maxWidth: '500px',
    marginTop: '20px',
    borderRadius: '8px',
    overflow: 'hidden',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
  },
  previewImage: {
    width: '100%',
    height: 'auto',
    display: 'block',
  },
  button: {
    padding: '12px 30px',
    backgroundColor: '#34495e',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '16px',
    fontWeight: 'bold',
    transition: 'background-color 0.3s ease',
    marginTop: '20px',
  },
  buttonDisabled: {
    backgroundColor: '#ccc',
    cursor: 'not-allowed',
  },
  loadingSpinner: {
    color: 'white',
    marginRight: '8px',
  },
} as const;

export const PostPage = memo(function PostPage() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);

      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result as string);
      };
      reader.readAsDataURL(selectedFile);
    }
  }, []);

  const handleUpload = useCallback(async () => {
    if (!file) return;
    setIsUploading(true);
    try {
      const storageRef = ref(storage, `images/${Date.now()}_${file.name}`);
      await uploadBytes(storageRef, file);
      alert('アップロード成功！');
      setFile(null);
      setPreview(null);
    } catch (error) {
      console.error('アップロードエラー:', error);
      alert('アップロードに失敗しました。');
    } finally {
      setIsUploading(false);
    }
  }, [file]);

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>
        画像アップロード
      </h2>

      <div style={styles.uploadArea}>
        <div style={styles.dropZone}>
          <input
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            style={styles.input}
            id="file-input"
            disabled={isUploading}
          />
          <label htmlFor="file-input" style={styles.label}>
            <CloudUploadIcon style={styles.icon} />
            <div style={styles.text}>
              クリックして画像を選択
              {file && (
                <div style={styles.fileName}>
                  選択されたファイル: {file.name}
                </div>
              )}
            </div>
          </label>
        </div>

        {preview && (
          <div style={styles.previewContainer}>
            <img
              src={preview}
              alt="プレビュー"
              style={styles.previewImage}
            />
          </div>
        )}

        <button
          onClick={handleUpload}
          disabled={!file || isUploading}
          style={{
            ...styles.button,
            ...((!file || isUploading) && styles.buttonDisabled),
          }}
        >
          {isUploading ? (
            <>
              <CircularProgress 
                size={20} 
                style={styles.loadingSpinner}
              />
              アップロード中...
            </>
          ) : (
            'アップロード'
          )}
        </button>
      </div>
    </div>
  );
});

export default PostPage;
