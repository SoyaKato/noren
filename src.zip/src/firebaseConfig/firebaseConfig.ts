import { initializeApp } from "firebase/app";
const firebaseConfig = {
  apiKey: "AIzaSyBrcoNCi3PGW2Vf9PC5B2fmqfu9awMOXJ0",
  authDomain: "webfront-2292d.firebaseapp.com",
  projectId: "webfront-2292d",
  storageBucket: "webfront-2292d.appspot.com",
  messagingSenderId: "360279863559",
  appId: "1:360279863559:web:b0f73258861061186cd5a2",
  measurementId: "G-5J5P8JGX3K",
};

export const firebaseApp = initializeApp(firebaseConfig);
