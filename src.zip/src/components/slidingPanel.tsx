import { useContext, memo } from "react";
import { SlidingContext } from "./context/sidebar";
import { SearchPage } from "@/page/search";
import { UserPage } from "@/page/user";
import { PostPage } from "@/page/post";

export const SlidingPanel = memo(function SlidingPanel(): JSX.Element | null {
  const slidingContext = useContext(SlidingContext);

  if (process.env.NODE_ENV === 'development') {
    console.log("Current sliding title:", slidingContext?.slidingTitle);
  }

  if (slidingContext?.slidingTitle === "undisplay") {
    return null;
  }

  const renderContent = () => {
    switch (slidingContext?.slidingTitle) {
      case "投稿":
        return <PostPage />;
      case "ユーザー":
        return <UserPage />;
      case "トレンド":
        return <SearchPage />;
      default:
        return null;
    }
  };

  return (
    <div className="sliding-panel">
      {renderContent()}
    </div>
  );
});
