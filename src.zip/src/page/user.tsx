import { GetImg } from "@/api/firebase/getImg";
export function UserPage() {
  return (
    <div>
      <div>UserPage</div>
      <GetImg imgPath="IMG_20181213_204012.jpg" />
    </div>
  );
}
