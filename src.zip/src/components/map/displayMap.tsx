import React, { useEffect, useState, useRef, useContext } from "react";
import { Gps } from "@/type/type";
import { shopsearch } from "@/api/here/shopSearch";
import { routeSearch } from "@/api/here/routeSearch";
import { SearchResult } from "@/type/type";
import { SlidingContext } from "../context/sidebar";
import { Rooting } from "./rooting";
import { CircularProgress } from '@mui/material';

interface DisplayMapProps {
  apikey: string;
  origin: Gps;
}

declare global {
  interface Window {
    H: any;
  }
}

export function DisplayMap({ apikey, origin }: DisplayMapProps) {
  const mapRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<any>(null);
  const currentPositionMarkerRef = useRef<any>(null);
  const [shopResult, setShopResult] = useState<SearchResult[]>([]);
  const [searchText, setSearchText] = useState("");
  const [destination, setDestination] = useState<Gps | null>(null);
  const slidingTitle = useContext(SlidingContext);
  const [rootingDisplay, setRootingDisplay] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  const handleChangeShops = (e: React.ChangeEvent<HTMLInputElement>) => {
    const searchText = e.target.value;
    setSearchText(searchText);

    if (searchText.trim() === "") {
      setShopResult([]);
      setDestination(null);
      return;
    }

    const fetchShops = async () => {
      try {
        setLoading(true);
        const result: SearchResult[] = await shopsearch(apikey, searchText, origin);
        setShopResult(result);
      } catch (error) {
        console.error("Error fetching shop results:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchShops();
  };

  const handleSearchRoute = async (index: number) => {
    const targetShop = shopResult[index];
    setDestination(targetShop.position);
    setRootingDisplay(true);
  };

  useEffect(() => {
    if (!mapRef.current) {
      console.error("mapRef.current is not initialized");
      return;
    }

    const H = window.H;
    const platform = new H.service.Platform({ apikey });
    const defaultLayers = platform.createDefaultLayers();

    const omvService = platform.getOMVService({
      path: "v2/vectortiles/core/mc",
    });
    const baseUrl = "https://js.api.here.com/v3/3.1/styles/omv/oslo/japan/";

    const style = new H.map.Style(`${baseUrl}normal.day.yaml`, baseUrl);
    const omvProvider = new H.service.omv.Provider(omvService, style);
    const omvLayer = new H.map.layer.TileLayer(omvProvider, {
      max: 22,
      dark: true,
    });

    const map = new H.Map(mapRef.current, omvLayer, {
      zoom: 16,
      center: { lat: origin.lat, lng: origin.lng },
    });

    const handleResize = () => map.getViewPort().resize();
    window.addEventListener("resize", handleResize);

    new H.mapevents.Behavior(new H.mapevents.MapEvents(map));
    H.ui.UI.createDefault(map, defaultLayers);

    mapInstanceRef.current = map;

    const marker = new H.map.Marker({ lat: origin.lat, lng: origin.lng });
    map.addObject(marker);
    currentPositionMarkerRef.current = marker;

    return () => {
      window.removeEventListener("resize", handleResize);
      map.dispose();
    };
  }, [apikey, origin]);

  useEffect(() => {
    if (!mapInstanceRef.current || !currentPositionMarkerRef.current) return;

    const map = mapInstanceRef.current;
    const currentPositionMarker = currentPositionMarkerRef.current;

    currentPositionMarker.setGeometry({ lat: origin.lat, lng: origin.lng });
    map.setCenter({ lat: origin.lat, lng: origin.lng });
  }, [origin]);

  useEffect(() => {
    if (!mapInstanceRef.current) return;

    const H = window.H;
    const map = mapInstanceRef.current;

    const objectsToRemove = map
      .getObjects()
      .filter((obj: any) => obj !== currentPositionMarkerRef.current);
    map.removeObjects(objectsToRemove);

    shopResult.forEach((result) => {
      const position = result.position;
      const iconUrl = "/explore_nearby_24dp_EA3323_FILL0_wght400_GRAD0_opsz24.svg";
      const icon = new H.map.Icon(iconUrl);
      const searchMarker = new H.map.Marker(
        { lat: position.lat, lng: position.lng },
        { icon }
      );
      map.addObject(searchMarker);
    });

    const searchRoute = async () => {
      if (origin && destination) {
        try {
          const route = await routeSearch(apikey, origin, destination);
          if (route && route.polyline) {
            const linestring = H.geo.LineString.fromFlexiblePolyline(
              route.polyline
            );
            const newRouteLine = new H.map.Polyline(linestring, {
              style: { strokeColor: "blue", lineWidth: 3 },
            });
            map.addObjects([newRouteLine]);
            map
              .getViewModel()
              .setLookAtData({ bounds: newRouteLine.getBoundingBox() });
          } else {
            console.error("Route polyline is missing");
          }
        } catch (error) {
          console.error("Error searching route:", error);
        }
      }
    };

    searchRoute();
  }, [shopResult, destination]);

  return (
    <div className="map-container">
      <input
        type="text"
        className={`map-input ${
          slidingTitle?.slidingTitle !== "undisplay" || rootingDisplay
            ? "undisplay"
            : ""
        }`}
        onChange={handleChangeShops}
        placeholder="Search location ..."
      />
      {loading && <CircularProgress className="loading-spinner" />}
      {searchText.trim() !== "" && shopResult.length > 0 && (
        <div className={`shop-results ${rootingDisplay ? "undisplay" : ""}`}>
          {shopResult.map((result, index) => (
            <div
              onClick={() => handleSearchRoute(index)}
              key={index}
              className="shop-result-item"
            >
              <h3>{result.title}</h3>
              <p>
                Position: {result.position.lat}, {result.position.lng}
              </p>
              <p>Distance: {result.distance} meters</p>
            </div>
          ))}
        </div>
      )}
      <div className="mapingroot">
        <div className="map-ref" ref={mapRef} />
        <Rooting state={rootingDisplay} setState={setRootingDisplay}></Rooting>
      </div>
    </div>
  );
}

export default DisplayMap;
