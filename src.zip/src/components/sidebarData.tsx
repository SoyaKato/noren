import { NavLink } from "react-router-dom";
import MenuIcon from "@mui/icons-material/Menu";
import PermIdentityIcon from "@mui/icons-material/PermIdentity";
import SearchIcon from "@mui/icons-material/Search";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";

export const SidebarData = [
  {
    title: "メニュー",
    icon: <MenuIcon className="sidebar-icon" />,
    link: "/menu",
  },
  {
    title: "トレンド",
    icon: <SearchIcon className="sidebar-icon" />,
    link: "/search",
  },
  {
    title: "ユーザー",
    icon: <PermIdentityIcon className="sidebar-icon" />,
    link: "/user",
  },
  {
    title: "投稿",
    icon: <AddCircleOutlineIcon className="sidebar-icon" />,
    link: "/post",
  },
];

const Sidebar = () => {
  return (
    <div id="Sidebar">
      <ul>
        {SidebarData.map((item, index) => (
          <li key={index}>
            <NavLink
              to={item.link}
              className={({ isActive }) => (isActive ? "btn sidebar active" : "btn sidebar")}
            >
              {item.icon}
              <p>{item.title}</p>
            </NavLink>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Sidebar;
